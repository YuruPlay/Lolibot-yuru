console.log('Iniciando 🚀🚀🚀') 
import cfonts from 'cfonts';
import chalk from 'chalk';

cfonts.say('LoliBot-MD', {
  font: 'chrome',
  align: 'center',
  gradient: ['red', 'magenta'],
  transition: false
});

cfonts.say('by: elrebelde21', {
  font: 'console',
  align: 'center',
  gradient: ['red', 'magenta'],
  transition: false
});

//console.clear();

import('./main.js');
