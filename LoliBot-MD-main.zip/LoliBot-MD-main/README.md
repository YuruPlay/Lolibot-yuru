<p align="center">
  <img src="https://telegra.ph/file/c3396a8d9b8ba43aed33e.jpg" width="800"/>
</p>

<p align="center">
  <img src="https://capsule-render.vercel.app/api?type=waving&color=F700FF&height=100&section=header&text=✨%20LoliBot-MD%20v2.0.0%20(BETA)%20✨&fontSize=32&fontColor=ffffff" />
</p>

<p align="center">
  <img src="http://readme-typing-svg.herokuapp.com?font=Fira+Code&size=18&duration=3500&pause=1000&color=FF69B4&center=true&vCenter=true&width=500&lines=🔮+Rediseñado+desde+0+para+Mejor+estabilidad+rendimiento" />
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Versión-BETA_2.0.0-FF69B4?style=for-the-badge&logo=github">
  <img src="https://img.shields.io/github/stars/elrebelde21/LoliBot-MD?color=yellow&style=for-the-badge" alt="stars"/>
  <img src="https://img.shields.io/github/forks/elrebelde21/LoliBot-MD?color=blue&style=for-the-badge" alt="forks"/>
</p>

<p align="center">
  <a href="https://whatsapp.com/channel/0029Vah0NnV6mYPDQI7bpt0z"><img src="https://img.shields.io/badge/-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
  <a href="https://www.youtube.com/@elrebelde.21"><img src="https://img.shields.io/badge/-FF0000?style=for-the-badge&logo=youtube"/></a>
  <a href="https://www.facebook.com/elrebelde21"><img src="https://img.shields.io/badge/-1877F2?style=for-the-badge&logo=facebook"/></a>
  <a href="https://www.instagram.com/itschinita_official"><img src="https://img.shields.io/badge/-E4405F?style=for-the-badge&logo=instagram"/></a>
  <a href="https://www.tiktok.com/@elrebeldee21"><img src="https://img.shields.io/badge/-000000?style=for-the-badge&logo=tiktok"/></a>
</p>

---

<p align="center">
  <a href="https://github.com/elrebelde21">
    <img src="http://readme-typing-svg.herokuapp.com?font=Fira+Code&size=20&duration=3500&pause=1000&color=FF69B4&center=true&vCenter=true&width=500&lines=LoliBot-MD+%F0%9F%90%88+%F0%9F%94%A5+Versi%C3%B3n+2.0.0+%28Beta%29;Ahora+m%C3%A1s+r%C3%A1pido+y+potente;Gracias+por+apoyar+el+proyecto+%F0%9F%92%96" />
  </a>
</p>

---

### 💫 Duda sobre el bot?, contactarme ✨

<a href="http://wa.me/573226873710" target="blank"><img src="https://img.shields.io/badge/Creador-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /> 

<a href="http://wa.me/595975610288?text=.estado" target="blank"><img src="https://img.shields.io/badge/Bot oficial-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>

### ❇️ GRUPOS OFICIALES

<a href="https://chat.whatsapp.com/HNDVUxHphPzG3cJHIwCaX5" target="blank"><img src="https://img.shields.io/badge/Grupo LoliBot ofc 1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /> 
<a href="https://chat.whatsapp.com/H4hxytyGvucIF1k0UAR7es" target="blank"><img src="https://img.shields.io/badge/Grupo LoliBot ofc 2-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://chat.whatsapp.com/IO5k0UOF7hOJHE1eH3Fcxh" target="blank"><img src="https://img.shields.io/badge/🐈 𝐆𝐚𝐭𝐚𝐁𝐨𝐭 & 𝐋𝐨𝐥𝐢𝐁𝐨𝐭 🥳-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://chat.whatsapp.com/IstOAq2RnBx687WhQpOYK8" target="blank"><img src="https://img.shields.io/badge/𝐄𝐧𝐥𝐚𝐜𝐞 𝐋𝐨𝐥𝐢𝐁𝐨𝐭 -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://chat.whatsapp.com/Jpshmvl9Ey4K30zKHoK20q" target="blank"><img src="https://img.shields.io/badge/💫 𝘾𝙤𝙢𝙪𝙣𝙞𝙙𝙖𝙙 𝙇𝙤𝙡𝙞𝘽𝙤𝙩 🥳-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>

---

## 🚀 Características destacadas

<p align="center">

<table>
  <tr>
    <th>🧠 Función</th>
    <th>✨ Descripción</th>
  </tr>
  <tr>
    <td>🤖 Jadibot</td>
    <td>Conexión y reconexión automática</td>
  </tr>
  <tr>
    <td>📥 Descargas</td>
    <td>Soporte para descargar de YouTube, TikTok, Instagram y más</td>
  </tr>
  <tr>
    <td>🛡️ Gestión de Grupos</td>
    <td>Anti-enlaces, bienvenida, antifake, modo admin y más</td>
  </tr>
  <tr>
    <td>⚔️ Sistema RPG</td>
    <td>Sistema de gacha, Sube de nivel, gana recompensas, juega con otros</td>
  </tr>
  <tr>
    <td>🎮 Juegos</td>
    <td>Adivina, reto, piedra papel tijera, ruleta y más</td>
   </tr>
  <tr>
    <td>💻 Base de datos</td>
    <td>PostgreSQL para una mayor eficiencia y escalabilidad</td>
  </tr>
  <tr>
    <td>🚧 En constante mejora</td>
    <td>Siempre en evolución con nuevas ideas y funciones</td>
  </tr>
</table>

</p>

---

### ☁️ Activar LoliBot-MD 24/7 activos en SkyPlus Host
[![YouTube](https://img.shields.io/badge/SkyUltraPlus-Host-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/fZbcCLpSH6Y?si=1sDen7Bzmb7jVpAI)

<a href="https://dash.corinplus.com"><img src="https://qu.ax/zFzXF.png" height="125px"></a>

### Información del Host
- **Pagina Oficial:** [`Aqui`](https://skyultraplus.com)
- **Dashboard:** [`Aquí`](https://dash.skyultraplus.com)
- **Panel:** [`Aquí`](https://panel.skyultraplus.com)
- **Estado de servicios:** [`Aquí`](https://estado.skyultraplus.com)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VakUvreFHWpyWUr4Jr0g)
- **Comunidad:** [`Aquí`](https://chat.whatsapp.com/JPwcXvPEUwlEOyjI3BpYys)
- **Contacto(s):** [`Gata Dios`](https://wa.me/message/B3KTM5XN2JMRD1) / [`Russell`](https://api.whatsapp.com/send/?phone=15167096032&text&type=phone_number&app_absent=0) / [`elrebelde21`](https://facebook.com/elrebelde21)
- **Discord:** [`aqui`](https://discord.gg/Ph4eWsZ8)

- [x] **Configuración** <details><summary>**Ajustes del Servidor - LoliBot-MD**</summary><img src="https://telegra.ph/file/7ddd30dd7d77354fb01fe.jpg"></details>

----
## 🔰 Instalación por Termux

[![Tutorial](https://img.shields.io/badge/Tutorial-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/O_j2q5xCg3A)

[![Termux](https://img.shields.io/badge/Instalar%20Termux-000000?style=for-the-badge&logo=android&logoColor=white)](https://f-droid.org/es/packages/com.termux/)

> [!IMPORTANT]
> **No garantizamos un funcionamiento perfecto en Termux. Es normal que el bot funcione con lentitud o errores, te recomendamos considerar los servicios de alojamiento de bots de nuestros patrocinadores.**

### 📦 Comandos de instalación

```bash
termux-setup-storage
```

```bash
apt update && apt upgrade -y && pkg install -y git nodejs ffmpeg imagemagick yarn
```

```bash
git clone https://github.com/elrebelde21/LoliBot-MD && cd LoliBot-MD
```

```bash
bash install.sh
```

```bash
npm start
```

---

## 👨‍💻 Desarrollador principal

<p align="center">
  <a href="https://github.com/elrebelde21">
    <img src="https://github.com/elrebelde21.png" width="150" height="150" alt="elrebelde21"/><br>
    <b>@elrebelde21</b>
  </a>
</p>

<p align="center">
  <b>👑 Dueña/Propietaria:</b><br>
  <a href="https://www.instagram.com/itschinita_official">
    <img src="https://files.catbox.moe/4rbw47.jpg" width="130" height="130" style="border-radius: 50%;" alt="china"/><br>
    <b>@itschinita_official</b>
  </a>
</p>

---

## 👥 Colaboradores

<p align="center">
  <img src="https://github.com/GataNina-Li.png?size=100">
  <img src="https://github.com/AzamiJs.png?size=100">
  <img src="https://github.com/Alba070503.png?size=100">
  <img src="https://github.com/edar123.png?size=100">
</p>

---

<h2 align="center">⚠️ AVISOS IMPORTANTES</h2>

<p align="center">
  <img src="https://capsule-render.vercel.app/api?type=waving&color=F700FF&height=60&section=header&text=¡Lee+esto+antes+de+usar+el+bot!&fontSize=20&fontColor=ffffff" />
</p>

<p align="center">
  <sub>
    🚧 <b>Este repositorio publica la versión actual y oficial de LoliBot-MD.</b><br>
    📢 Es posible que el bot tenga algunas fallas; se irán corrigiendo conforme se detecten.<br>
    ✂️ Si vas a editar o compartir el bot, <b>no elimines los créditos originales</b>.<br>
    🎯 Atento a las nuevas actualizaciones que se realicen en este repositorio.<br>
    🔒 <b>LoliBot-MD no se hace responsable</b> del uso, número, privacidad ni contenido enviado, usado o gestionado por los usuarios o el bot. Úsalo bajo tu responsabilidad.<br>
    🚧 <b>Actualmente está en versión <span style="color:#FF44CC">BETA</span> en desarrollo.</b><br>
  </sub>
</p>

<p align="center">
  <img src="https://capsule-render.vercel.app/api?type=waving&color=F700FF&height=60&section=footer" />
</p>

---

<p align="center">
  <img src="https://github.com/siegrin/siegrin/blob/main/Assets/Handshake.gif" height="40px">
</p>

<p align="center">
  <img src="https://capsule-render.vercel.app/api?type=rect&color=F700FF&height=60&section=footer" />
</p
